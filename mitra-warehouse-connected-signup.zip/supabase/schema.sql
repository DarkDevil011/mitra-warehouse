-- MITRA WAREHOUSE: schema اولیه برای Supabase
-- این فایل را یک‌بار در SQL Editor پروژه Supabase اجرا کنید.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'کاربر انبار',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'display_name',''), split_part(coalesce(new.email,''),'@',1), 'کاربر انبار')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
after insert on auth.users
for each row execute procedure public.create_profile_for_new_user();

create table if not exists public.warehouse_records (
  store_name text not null check (store_name in ('products','transactions','history','recycleBin','settings')),
  record_id text not null,
  payload jsonb not null,
  created_by uuid references auth.users(id),
  updated_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (store_name, record_id)
);

create index if not exists warehouse_records_store_idx on public.warehouse_records(store_name);
create index if not exists warehouse_records_updated_idx on public.warehouse_records(updated_at desc);

create table if not exists public.warehouse_audit (
  id bigint generated always as identity primary key,
  store_name text not null,
  record_id text not null,
  action text not null check (action in ('INSERT','UPDATE','DELETE')),
  actor_id uuid references auth.users(id),
  actor_name text,
  before_data jsonb,
  after_data jsonb,
  happened_at timestamptz not null default now()
);
create index if not exists warehouse_audit_time_idx on public.warehouse_audit(happened_at desc);
create index if not exists warehouse_audit_actor_idx on public.warehouse_audit(actor_id, happened_at desc);

create or replace function public.audit_warehouse_record()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_actor uuid;
  v_name text;
  v_store text;
  v_id text;
  v_before jsonb;
  v_after jsonb;
begin
  v_actor := auth.uid();
  if v_actor is not null then
    select display_name into v_name from public.profiles where id = v_actor;
  end if;

  if tg_op = 'INSERT' then
    v_store := new.store_name; v_id := new.record_id;
    v_before := null; v_after := new.payload;
    insert into public.warehouse_audit(store_name,record_id,action,actor_id,actor_name,before_data,after_data)
    values(v_store,v_id,'INSERT',v_actor,coalesce(v_name,'کاربر'),v_before,v_after);
    return new;
  elsif tg_op = 'UPDATE' then
    v_store := new.store_name; v_id := new.record_id;
    v_before := old.payload; v_after := new.payload;
    insert into public.warehouse_audit(store_name,record_id,action,actor_id,actor_name,before_data,after_data)
    values(v_store,v_id,'UPDATE',v_actor,coalesce(v_name,'کاربر'),v_before,v_after);
    return new;
  else
    v_store := old.store_name; v_id := old.record_id;
    v_before := old.payload; v_after := null;
    insert into public.warehouse_audit(store_name,record_id,action,actor_id,actor_name,before_data,after_data)
    values(v_store,v_id,'DELETE',v_actor,coalesce(v_name,'کاربر'),v_before,v_after);
    return old;
  end if;
end;
$$;

drop trigger if exists warehouse_record_audit on public.warehouse_records;
create trigger warehouse_record_audit
after insert or update or delete on public.warehouse_records
for each row execute function public.audit_warehouse_record();

-- تصاویر مشترک؛ زمان انقضا از لحظه بارگذاری ۳۰ ساعت است.
create table if not exists public.warehouse_photos (
  id uuid primary key default gen_random_uuid(),
  storage_path text not null unique,
  caption text,
  uploaded_by uuid not null references auth.users(id),
  uploader_name text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '30 hours')
);
create index if not exists warehouse_photos_expiry_idx on public.warehouse_photos(expires_at);

alter table public.profiles enable row level security;
alter table public.warehouse_records enable row level security;
alter table public.warehouse_audit enable row level security;
alter table public.warehouse_photos enable row level security;

drop policy if exists "profiles readable by signed in users" on public.profiles;
create policy "profiles readable by signed in users" on public.profiles
for select to authenticated using (true);

drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "all signed in users manage warehouse records" on public.warehouse_records;
create policy "all signed in users manage warehouse records" on public.warehouse_records
for all to authenticated using (true) with check (true);

drop policy if exists "signed in users read audit" on public.warehouse_audit;
create policy "signed in users read audit" on public.warehouse_audit
for select to authenticated using (true);

-- درج در audit فقط از trigger مجاز است؛ کاربران اجازه دستکاری مستقیم ندارند.
revoke insert, update, delete on public.warehouse_audit from anon, authenticated;
grant select on public.warehouse_audit to authenticated;

drop policy if exists "signed in users read photos" on public.warehouse_photos;
create policy "signed in users read photos" on public.warehouse_photos
for select to authenticated using (true);

drop policy if exists "signed in users upload photo metadata" on public.warehouse_photos;
create policy "signed in users upload photo metadata" on public.warehouse_photos
for insert to authenticated with check (uploaded_by = auth.uid());

drop policy if exists "signed in users delete photo metadata" on public.warehouse_photos;
create policy "signed in users delete photo metadata" on public.warehouse_photos
for delete to authenticated using (true);

-- مخزن خصوصی عکس‌ها
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('warehouse-photos','warehouse-photos',false,10485760,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = false, file_size_limit = 10485760,
  allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "authenticated can read warehouse photos" on storage.objects;
create policy "authenticated can read warehouse photos" on storage.objects
for select to authenticated using (bucket_id = 'warehouse-photos');

drop policy if exists "authenticated can upload warehouse photos" on storage.objects;
create policy "authenticated can upload warehouse photos" on storage.objects
for insert to authenticated with check (bucket_id = 'warehouse-photos');

drop policy if exists "authenticated can delete warehouse photos" on storage.objects;
create policy "authenticated can delete warehouse photos" on storage.objects
for delete to authenticated using (bucket_id = 'warehouse-photos');

-- فعال‌سازی همگام‌سازی زنده
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'warehouse_records'
  ) then
    alter publication supabase_realtime add table public.warehouse_records;
  end if;
end $$;
